clear all;
dataDirectoryName = 'C:\TRIPaper\';
pixelSize = 4.733;

tmp = load(fullfile(dataDirectoryName, 'Figure2_abd.mat'));
cellMap = tmp.cellMap_example;
toothActivity_example = tmp.toothActivity_example;
lipActivity_example  = tmp.lipActivity_example;
selectivityMap = tmp.selectivityMap_example;
selectivityMap_example = tmp.selectivityMap_example;
onFrameNumber = tmp.onFrameNumber;
offFrameNumber = tmp.offFrameNumber;
msPerFrame = tmp.msPerFrame;
cell_1 = tmp.cell_1_individual;
cell_2 = tmp.cell_2_individual;



figure('Name', ['tooth']); imagesc(cellMap(:,:,1), [0, 0.15]); colormap(gray); 
figure('Name', ['lip']); imagesc(cellMap(:,:,2), [0, 0.15]); colormap(gray);
%figure('Name', ['selectivity index']); imagesc(cellMapForSectivityIndices(:, 256:end), [-1, 1]); colormap(gray);axis equal;
figure('Name', 'Heatmap');
subplot(1,2,1); imagesc(toothActivity_example, [0, 0.1]); colorbar; set(gca, 'Xtick', [], 'YTick', [50], 'Box', 'off', 'TickDir', 'out');colormap(gray);
subplot(1,2,2); imagesc(lipActivity_example, [0, 0.1]); colorbar; set(gca, 'XTick', [], 'YTick', [50], 'Box', 'off', 'TickDir', 'out');colormap(gray);

figure('Name', ['selectivity index']); imagesc(selectivityMap_example, [-1, 1]); colormap(gray); axis equal;

figure('Name', 'cell 1', 'Position', [100, 100, 500, 100]);
subplot(1,3,1); plot(squeeze(cell_1(:,:,1)), 'Color', [0, 0, 0]);set(gca, 'XLim', [0, 450], 'YLim', [-0.05, 0.15]);
xline(onFrameNumber, 'Color', [0, 0, 0]);xline(offFrameNumber, 'Color', [0, 0, 0]);axis off;
subplot(1,3,2); plot(squeeze(cell_1(:,:,2)), 'Color', [0.5, 0.5, 0.5]);set(gca, 'XLim', [0, 450], 'YLim', [-0.05, 0.15]);
xline(onFrameNumber, 'Color', [0, 0, 0]);xline(offFrameNumber, 'Color', [0, 0, 0]);axis off
subplot(1,3,3); plot(mean(squeeze(cell_1(:,:,1)),2), 'Color', [0, 0, 0]); hold on; plot(mean(squeeze(cell_1(:,:,2)),2), 'Color', [0.5,0.5,0.5]);set(gca, 'XLim', [0, 450], 'YLim', [-0.05, 0.15]);
xline(onFrameNumber, 'Color', [0, 0, 0]);xline(offFrameNumber, 'Color', [0, 0, 0]);axis off

figure('Name', 'cell 2', 'Position', [100, 100, 500, 100]);
subplot(1,3,1); plot(squeeze(cell_2(:,:,1)), 'Color', [0, 0, 0]);set(gca, 'XLim', [0, 450], 'YLim', [-0.05, 0.15]);
xline(onFrameNumber, 'Color', [0, 0, 0]);xline(offFrameNumber, 'Color', [0, 0, 0]); axis off;
subplot(1,3,2); plot(squeeze(cell_2(:,:,2)), 'Color', [0.5, 0.5, 0.5]);set(gca, 'XLim', [0, 450], 'YLim', [-0.05, 0.15]);
xline(onFrameNumber, 'Color', [0, 0, 0]);xline(offFrameNumber, 'Color', [0, 0, 0]); axis off;
subplot(1,3,3); plot(mean(squeeze(cell_2(:,:,1)),2), 'Color', [0, 0, 0]); hold on; plot(mean(squeeze(cell_2(:,:,2)),2), 'Color', [0.5,0.5,0.5]);set(gca, 'XLim', [0, 450], 'YLim', [-0.05, 0.15]);
plot([430-(3000/msPerFrame), 430], [-0.02, -0.02], 'Color', [0, 0, 0]);%3s scale bar
plot([430, 430], [-0.02, 0.08], 'Color', [0, 0, 0]);%10% scale bar;
xline(onFrameNumber, 'Color', [0, 0, 0]);xline(offFrameNumber, 'Color', [0, 0, 0]); axis off;



tmp = load(fullfile(dataDirectoryName, 'Figure2_ce.mat'));
selectivityIndices_allcells = tmp.selectivityIndices_allcells;
cellPositions_allcells = tmp.cellPositions_allcells;
centerOfGravity_allmice = tmp.centerOfGravity_allmice;

figure('Name', 'histogram for A-B/A+B');
[N, X] = hist(selectivityIndices_allcells, [-1:0.1:1]);
bar(X, N/sum(N), 1, 'FaceColor', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XTick', [-1, 0, 1], 'XLim', [-1.2, 1.2], ...
    'YLim', [0, 0.22], 'YTick', [0:0.2:0.4],  ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

figure('Name', 'Spatial distribution of all selective cells');
hold on;
for ii = 1:size(selectivityIndices_allcells,1)
        plot(cellPositions_allcells(ii,1), cellPositions_allcells(ii,2), '.', 'MarkerSize', 10, 'Color', [1, 1, 1]*(selectivityIndices_allcells(ii)+1)/2)
end
plot([100,100+100/pixelSize], [-200, -200], '-', 'Color', [0, 0, 0]);
plot([100,100+100/pixelSize], [-200, -200], '-', 'Color', [0, 0, 0]);
set(gca, 'TickDir', 'out');
axis equal
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'Color', [0.5, 0.5, 0.5], 'XLim', [-150 150], 'XTick', [-100:100:100], ...
    'YLim', [-250, 250],  'YTick', [-200:200:200], ...
    'LineWidth', 0.5, 'TickLength', [0.005 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

figure('Name', 'center of gravity for each mouse');
plot([zeros(1, size(centerOfGravity_allmice,1)); centerOfGravity_allmice(:,1)'],[zeros(1, size(centerOfGravity_allmice,1)); centerOfGravity_allmice(:,2)'], 'Color', [0, 0, 0], 'LineWidth', 1);
hold on;
plot([0, 0], [-70, 70], '-', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.2);
plot([-35, 35], [0, 0], '-', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.2);
plot([40-100/pixelSize, 40], [-40, -40], '-', 'Color', [0, 0, 0]);
plot([40, 40], [-40, -40+100/pixelSize], '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-70, 70], ...
    'YLim', [-70, 70],  ...
    'LineWidth', 0.5, 'TickLength', [0.005 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
axis square
axis off

