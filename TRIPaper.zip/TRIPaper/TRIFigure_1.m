clear all;
pixelSize = 4.733;
dataDirectoryName = 'C:\TRIPaper\';

tmp = load(fullfile(dataDirectoryName, 'Figure1_efg.mat'));
figure('Name', 'Full view');
subplot(1,3,1); imagesc(tmp.Image_Baseline, tmp.lookup_for_all); colormap(gray); title('Baseline'); axis off; axis square;
subplot(1,3,2); imagesc(tmp.Image_Response, tmp.lookup_for_all); colormap(gray); title('Response'); axis off; axis square;
subplot(1,3,3); imagesc(tmp.Image_DFF, tmp.lookup_for_DFF); colormap(gray); title('DFF'); axis off; axis square;
figure('Name', 'Zoomed in');
subplot(1,3,1); imagesc(tmp.Image_Baseline(tmp.ROIposition1(1):tmp.ROIposition1(2), tmp.ROIposition2(1):tmp.ROIposition2(2)), tmp.lookup_for_ROI); colormap(gray); title('Baseline'); axis off; axis square;
subplot(1,3,2); imagesc(tmp.Image_Response(tmp.ROIposition1(1):tmp.ROIposition1(2), tmp.ROIposition2(1):tmp.ROIposition2(2)), tmp.lookup_for_ROI); colormap(gray); title('Response'); axis off; axis square;
subplot(1,3,3); imagesc(tmp.Image_DFF(tmp.ROIposition1(1):tmp.ROIposition1(2), tmp.ROIposition2(1):tmp.ROIposition2(2)), tmp.lookup_for_DFF); colormap(gray); title('Response'); axis off; axis square;

figure('Name', 'Raw Data zoomed in 3D')
surf(tmp.Image_DFF(tmp.ROIposition1(1):tmp.ROIposition1(2), tmp.ROIposition2(1):tmp.ROIposition2(2)));
set(gca, 'LineWidth', 3, 'GridLineWidth', 1, 'XTick', [0:100/pixelSize:100/pixelSize*3], 'XTickLabel',  [], ...
    'YTick', [0:100/pixelSize:100/pixelSize*3], 'YTickLabel', [], ...
    'ZTick', [0:20:20], 'ZTickLabel', []);
clear tmp

figure('Name', 'size distribution')
tmp = load(fullfile(dataDirectoryName, 'Figure1_h.mat'));
radius_each = tmp.radius_each;
[N,X] = hist(radius_each, [0:2.5:40]);
h = bar(X, N/sum(N), 1);
set(h, 'FaceColor', [0, 0, 0], 'EdgeColor', [0, 0, 0]);
set(gca, 'XLim', [-0.1 45], 'XTick', [0:20:40], 'XTickLabel', [0:20:40], 'YLim', [0 0.2], 'YTick', [0:0.1:1], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', ...
    'FontName', 'Arial', 'FontSize', 8, 'tag', 'size distribution');
disp(['median + SEM = ', num2str(median(radius_each), '%3.1f') , '+', num2str(std(radius_each)/sqrt(length(radius_each)), '%3.1f')])
disp(['N=', int2str(length(radius_each))])
